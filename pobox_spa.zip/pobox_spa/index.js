const express = require('express');
const port =2507;
const app  = express();
app.use(express.json());
let allData = [];

let bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: false}));

const path = require('path');
app.use(express.static(path.join(__dirname, "public")));
app.get('/',(req,res)=> {
    res.sendFile("./Views/spa_main.html",{root:__dirname})
});

app.post('/ADD',(req,res)=>{
    let line1 = {};

    line1.Name = req.body.Name;
    line1.Phone = req.body.Phone;
    line1.Pobox = req.body.Pobox;
    if (line1.Name !== "" )
        allData.push(line1);
    console.log(allData)
    res.send('ready to add EndPoint');
})

app.post('/ADD2',(req,res)=>{
    let line1 = {};
    line1.Name = req.body.Name1;
    line1.Phone = req.body.Phone1;
    line1.Pobox = req.body.Pobox;
        allData.push(line1);
    line1 = {};
    line1.Name = req.body.Name2;
    line1.Phone = req.body.Phone2;
    line1.Pobox = req.body.Pobox;

        allData.push(line1);

    console.log(allData)
    res.send('ready to add EndPoint');
})
app.get('/list',(req ,res)=>{
    res.send(allData);
})
app.listen(port,()=>{
    console.log(`now listening on port ${port}`);
})